using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;
    public int collisionDamage = 10;

    void Start()
    {
        currentHealth = maxHealth;
    }

    void CollideEnemy(Collision collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            currentHealth -= collisionDamage;
            Debug.Log("Ouch");
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Destroy(gameObject);
    }
}