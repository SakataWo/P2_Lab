using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenBubble : MonoBehaviour
{
    private Collectable Greenbubble;

    private void Start()
    {
        Greenbubble = new Collectable("GreenBubble", 0, 5);
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            Debug.Log("Health regained!");
            Destroy(gameObject);
        }
    }
}
